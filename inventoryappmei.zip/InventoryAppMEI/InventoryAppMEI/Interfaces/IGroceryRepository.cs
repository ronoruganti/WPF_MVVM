﻿using InventoryAppMEI.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Dynamic;
using System.Text;

namespace InventoryAppMEI.Interfaces
{
    /// <summary>
    /// Interface representing a grocery repository
    /// </summary>
    public interface IGroceryRepository
    {
    }
}
