﻿using InventoryAppMEI.Models;
using System.Collections.ObjectModel;

namespace InventoryAppMEI.Interfaces
{
    /// <summary>
    /// Interface representing a grocery manager service
    /// </summary>
    public interface IGroceryManager
    {
        public void AddOneFruit(string name);
        public void RemoveOneFruit(string name);
        public ObservableCollection<IGroceryModel> GetAllFruits();

        public int GetCount();
    }
}
