﻿using InventoryAppMEI.Helpers;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using System.IO;
using InventoryAppMEI.Views;
using InventoryAppMEI.Interfaces;
using InventoryAppMEI.ViewModels;
using InventoryAppMEI.Models;

namespace InventoryAppMEI
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        // Dependency injection provider
        public IServiceProvider ServiceProvider { get; private set; }

        public IConfiguration Configuration { get; private set; }

        protected override void OnStartup(StartupEventArgs e)
        {
            //Setup dependency injection
            var serviceCollection = new ServiceCollection();
            ConfigureServices(serviceCollection);

            ServiceProvider = serviceCollection.BuildServiceProvider();

            var mainWindowViewModel = ServiceProvider.GetRequiredService<MainWindowViewModel>();
            var  mainWindow = ServiceProvider.GetRequiredService<MainWindow>();

            //Assign data context here to allow for parameterless constructor #datacontextcomment
            mainWindow.DataContext = mainWindowViewModel;
            mainWindow.Show();
        }

        private void ConfigureServices(IServiceCollection services)
        {
            //Providing dependency services and their required concrete types
            services.AddScoped<IGroceryManager, FruitManager>();
            services.AddScoped<IGroceryRepository, FruitRepository>();
            services.AddScoped<IGroceryModel, FruitModel>();
            services.AddTransient<MainWindow>();
            services.AddTransient<MainWindowViewModel>();

        }
    }
}
