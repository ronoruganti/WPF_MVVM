﻿using InventoryAppMEI.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace InventoryAppMEI.Models
{
    /// <summary>
    /// Class representing the fruit 
    /// </summary>
    public class FruitModel : ViewModelBase, IGroceryModel
    {
        private int quantity = 1;
        private string name;

        public string Name
        {
            get { return name; }
            set
            {
                SetProperty(ref name, value);
            }
        }

        public int Quantity
        {
            get { return quantity; }
            set
            {
                SetProperty(ref quantity, value);
            }
        }

        public FruitModel(string name, int quantity)
        {
            this.Name = name;
            this.Quantity = quantity;
        }

        public FruitModel(string name)
        {
            this.Name = name;           
        }

        public FruitModel()
        {

        }
    }
}
