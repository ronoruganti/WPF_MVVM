﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InventoryAppMEI.Models
{
    /// <summary>
    /// interface representing grocery model
    /// </summary>
    public interface IGroceryModel
    {
        public string Name { get; set; }
    }
}
