﻿using InventoryAppMEI.Interfaces;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace InventoryAppMEI.Models
{
    //Repository holding the fruit collection
    public class FruitRepository : IGroceryRepository
    {
        public ObservableCollection<IGroceryModel> Fruits { get; set; } = new ObservableCollection<IGroceryModel>();
    }
}
