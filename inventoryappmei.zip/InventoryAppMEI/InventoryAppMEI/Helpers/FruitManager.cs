﻿using InventoryAppMEI.Interfaces;
using InventoryAppMEI.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace InventoryAppMEI.Helpers
{
    /// <summary>
    /// Implementation of fruit manager service
    /// </summary>
    public class FruitManager : IGroceryManager
    {
        private IGroceryRepository FruitRepository { get;  set; }
        private IGroceryModel Fruit { get; set; }
        static string PreviousFruitName = null;

        public FruitManager(IGroceryRepository fruitRepository, IGroceryModel fruitModel)
        {
            FruitRepository = fruitRepository;
            Fruit = fruitModel;
        }

        public void AddOneFruit(string name)
        {
            PreviousFruitName = name;
            (FruitRepository as FruitRepository).Fruits.Add(new FruitModel(name));
        }

        public int GetCount()
        {
            return (FruitRepository as FruitRepository).Fruits.Count;
        }

        public void RemoveOneFruit(string name)
        {
            (FruitRepository as FruitRepository).Fruits.Remove(new FruitModel(name));
        }

        public void RemoveOneFruit(FruitModel fruitModel)
        {
            (FruitRepository as FruitRepository).Fruits.Remove(fruitModel);
        }

        public ObservableCollection<IGroceryModel> GetAllFruits()
        {
            return (FruitRepository as FruitRepository).Fruits;      
        }
    }
}
