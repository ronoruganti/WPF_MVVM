﻿using InventoryAppMEI.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Windows.Data;

namespace InventoryAppMEI.Helpers
{
    /// <summary>
    /// Converter that sets the text when listview item is selected
    /// </summary>
    public class ClearTextBoxConverter : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            if ((bool)values[0] == true)
                return ((FruitModel)values[1])?.Name;
            else return Binding.DoNothing;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            return null;
        }
    }
}
