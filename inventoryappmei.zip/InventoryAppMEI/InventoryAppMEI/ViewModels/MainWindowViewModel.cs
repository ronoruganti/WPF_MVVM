﻿using InventoryAppMEI.Helpers;
using InventoryAppMEI.Interfaces;
using InventoryAppMEI.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows.Media;

namespace InventoryAppMEI.ViewModels
{
    /// <summary>
    /// Viewmodel that is assigned as the data context of MainWindow
    /// </summary>
    public class MainWindowViewModel : ViewModelBase
    {
        #region Commands

        public RelayCommand AddItemCommand { get; set; }
        public RelayCommand RemoveItemCommand { get; set; }

        #endregion Commands

        #region Properties
        
        ///Collection of fruits        
        public ObservableCollection<IGroceryModel> Fruits { get; set; }

        // Services that manages fruit operations
        private IGroceryManager FruitManager { get; set; }

        public FruitModel SelectedFruit { get; set; }

        #endregion Properties

        #region Constructors

        /// <summary>
        /// Constructor for view model with injected dependencies
        /// No parameterless contructor needed - see #datacontextcomment
        /// </summary>
        /// <param name="fruitManager"></param>
        public MainWindowViewModel(IGroceryManager fruitManager)
        {
            AddItemCommand = new RelayCommand(CanAddExecute, AddItem);
            RemoveItemCommand = new RelayCommand(CanRemoveExecute, RemoveItem);

            FruitManager = (FruitManager)fruitManager;
            Fruits = FruitManager.GetAllFruits();
        }

        #endregion Constructors

        #region CommandMethods

        /// <summary>
        /// Enable/disable add item button
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        private bool CanAddExecute(object obj)
        {
            return !string.IsNullOrEmpty(obj?.ToString());
        }

        /// <summary>
        /// Enable/disable remove item button
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        private bool CanRemoveExecute(object obj)
        {
            if (obj == null)
                return false;
            else return true;
        }

        /// <summary>
        /// Handles adding of fruit object
        /// </summary>
        /// <param name="fruitName"></param>
        private void AddItem(object fruitName)
        {
            if (Fruits.Where(x => x.Name == fruitName.ToString()).Count() > 0)
            {
                (Fruits.Where(x => x.Name == fruitName.ToString()).First() as FruitModel).Quantity += 1;
            }
            else if ((Fruits.Where(x => x.Name == SelectedFruit?.Name).Count() > 0) && (Fruits.Where(x => x.Name == fruitName.ToString()).Count() > 0))
            {
                (Fruits.Where(x => x.Name == SelectedFruit?.Name).First() as FruitModel).Quantity += 1;
            }
            else
                (FruitManager as FruitManager).AddOneFruit(fruitName.ToString());
        }

        /// <summary>
        /// Handles removing of fruit object
        /// </summary>
        /// <param name="fruitName"></param>
        private void RemoveItem(object selectedFruit)
        {
            if ((selectedFruit as FruitModel).Quantity > 1)         
            { 
                (Fruits.Where(x => x.Name == (selectedFruit as FruitModel)?.Name).First() as FruitModel).Quantity -= 1; 
            }
            else if ((selectedFruit as FruitModel).Quantity == 1)
            { 
                (FruitManager as FruitManager).RemoveOneFruit(selectedFruit as FruitModel); 
            }
        }

        #endregion CommandMethods
    }
}
