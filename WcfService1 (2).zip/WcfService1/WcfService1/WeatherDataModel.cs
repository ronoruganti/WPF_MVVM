﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace WeatherServiceApp
{
    // Use a data contract as illustrated in the sample below to add composite types to service operations.
    [DataContract]
    public class WeatherDataModel
    {

        [DataMember]
        public bool InclementWeatherAlert { get; set; }

        [DataMember]
        public string DailyForecast { get; set; }
        
        [DataMember]
        public string Temperature { get; set; }
        
        [DataMember]
        public string DateTime { get; set; }
        
        [DataMember]
        public string CityState { get; set; }

    }
}