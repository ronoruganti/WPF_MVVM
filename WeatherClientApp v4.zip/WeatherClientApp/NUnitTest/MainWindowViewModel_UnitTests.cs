using NUnit.Framework;
using ServiceReference1;
using System;
using System.Net;
using System.ServiceModel;
using WeatherClientApp;

namespace NUnitTestWeatherClientApp
{
    [TestFixture]
    public class Tests
    {
        MainWindowViewModel mainWindowViewModel { get; set; }

        // Can use real service instead of moq object
        //WeatherServiceClient client = new WeatherServiceClient(new BasicHttpBinding(), new EndpointAddress("http://localhost:60503/WeatherService.svc"));

        ChannelFactory<IWeatherServiceChannel> channel = new ChannelFactory<IWeatherServiceChannel>(new BasicHttpBinding(), new EndpointAddress("http://localhost:60503/WeatherService.svc"));

        [SetUp]
        public void Setup()
        {
            if (!UriParser.IsKnownScheme("pack"))
                new System.Windows.Application();

            _ = System.IO.Packaging.PackUriHelper.UriSchemePack;
            mainWindowViewModel = new MainWindowViewModel(channel);
        }

        [Test]
        public void Test_UpdateWeatherCommand_SucceedsWithValidZip_ReturnsRandomButValidWeatherData()
        {
            //Arrange
            string zip = "01671";

            //Act
            mainWindowViewModel.UpdateWeatherCommand.Execute(zip);

            //Assert
            Assert.IsNotNull(mainWindowViewModel.DailyForecast);
            Assert.IsNotNull(mainWindowViewModel.CityState);
            Assert.IsNotNull(mainWindowViewModel.DateTime);
            Assert.IsNotNull(mainWindowViewModel.ImageSource);
            Assert.IsNotNull(mainWindowViewModel.Temperature);

        }

        [Test]
        public void Test_UpdateWeatherCommand_Invalidzip7digits_CanExecuteTurnsFalse()
        {
            //Arrange
            string zip = "0167166";

            //Act
            var canExec = mainWindowViewModel.UpdateWeatherCommand.CanExecute(zip);

            //Assert
            Assert.IsFalse(canExec);

        }

        [Test]
        public void Test_UpdateWeatherCommand_Invalidzip3digits_CanExecuteTurnsFalse()
        {
            //Arrange
            string zip = "016";

            //Act
            var canExec = mainWindowViewModel.UpdateWeatherCommand.CanExecute(zip);

            //Assert
            Assert.IsFalse(canExec);

        }

        [Test]
        public void Test_UpdateWeatherCommand_Invalidzip_letters_CanExecuteTurnsFalse()
        {
            //Arrange
            string zip = "abc";

            //Act
            var canExec = mainWindowViewModel.UpdateWeatherCommand.CanExecute(zip);

            //Assert
            Assert.IsFalse(canExec);

        }
    }
}