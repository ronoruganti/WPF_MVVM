﻿using System;
using System.Windows;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.ServiceModel.Channels;
using System.ServiceModel;
namespace WeatherClientApp
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        // Dependency injection provider
        public IServiceProvider ServiceProvider { get; private set; }
        public IConfiguration Configuration { get; private set; }

        protected override void OnStartup(StartupEventArgs e)
        {
            //Setup dependency injection
            var serviceCollection = new ServiceCollection();
            ConfigureServices(serviceCollection);

            ServiceProvider = serviceCollection.BuildServiceProvider();

            var mainWindowViewModel = ServiceProvider.GetRequiredService<MainWindowViewModel>();
            var mainWindow = ServiceProvider.GetRequiredService<MainWindow>();

            //Assign data context here to allow for not requiring parameterless constructor #datacontextcomment
            mainWindow.DataContext = mainWindowViewModel;
            mainWindow.Show();
        }

        private void ConfigureServices(IServiceCollection services)
        {
            //Providing dependency services and their required concrete types

            var apps = System.Configuration.ConfigurationManager.AppSettings;
            var wc = ConfigurationManager.AppSettings["uri"];
            var section = ConfigurationManager.GetSection("system.serviceModel/client");

            var sc = services.AddScoped<IWeatherService>(scvProvider =>
            {
                var client = new WeatherServiceClient(new BasicHttpBinding(), new EndpointAddress(wc));
                return client;
            });

            services.AddTransient<MainWindow>();
            services.AddTransient<MainWindowViewModel>();

        }
    }
}
