﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.ServiceModel;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Automation;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace WeatherClientApp
{
    public class MainWindowViewModel : ViewModelBase
    {
        private ImageSource imageSource = new BitmapImage(new Uri(@"pack://application:,,,/Images/sunshine.jpg", UriKind.RelativeOrAbsolute));
        private string dailyForecast;
        private string cityState;
        private string dateTime;
        private string temperature;

        #region Properties

        public WeatherServiceClient weatherClient { get; set; }
        public string ZipCode { get; set; } = "01850";
        public string DailyForecast
        {
            get { return dailyForecast; }
            set
            {
                SetProperty(ref dailyForecast, value);
            }
        }
        public string CityState
        {
            get { return cityState; }
            set
            {
                SetProperty(ref cityState, value);
            }
        }
        public string DateTime
        {
            get { return dateTime; }
            set
            {
                SetProperty(ref dateTime, value);
            }
        }
        public string Temperature
        {
            get { return temperature; }
            set
            {
                SetProperty(ref temperature, value);
            }
        }

        public ImageSource ImageSource
        {
            get { return imageSource; }
            set
            {
                SetProperty(ref imageSource, value);
            }
        }

        #endregion Properties

        #region Commands

        public RelayCommand UpdateWeatherCommand { get; set; }
        public RelayCommand RemoveItemCommand { get; set; }

        #endregion Commands

        public MainWindowViewModel()
        {
            UpdateWeatherCommand = new RelayCommand(CanUpdateWeatherExecute, UpdateWeather);
            //Read from config file
            weatherClient = new WeatherServiceClient(new BasicHttpBinding(), new EndpointAddress("http://localhost:60503/WeatherService.svc"));
        }

        /// <summary>
        /// Enable/disable add item button
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        private bool CanUpdateWeatherExecute(object obj)
        {
            Regex reg = new Regex(@"^\d{5}(?:[-\s]\d{4})?$");
            if ((string.IsNullOrEmpty(obj?.ToString())) || (!(reg.IsMatch(obj?.ToString()))))
                return false;
            else return true;
        }


        /// <summary>
        /// Handles adding of fruit object
        /// </summary>
        /// <param name="fruitName"></param>
        private void UpdateWeather(object zip)
        {
            var weatherData = weatherClient.GetWeatherDataByZipUsingDataContract(zip.ToString());
            DailyForecast = weatherData.DailyForecast;
            Temperature = weatherData.Temperature;
            DateTime = weatherData.DateTime;

            switch (weatherData.DailyForecast)
            {
                case "rain":
                    ImageSource = new BitmapImage(new Uri(@"pack://application:,,,/Images/rain.jpeg", UriKind.RelativeOrAbsolute));
                    break;
                case "snow":
                    ImageSource = new BitmapImage(new Uri(@"pack://application:,,,/Images/snow.jpg", UriKind.RelativeOrAbsolute));
                    break;
                case "sun":
                    ImageSource = new BitmapImage(new Uri(@"pack://application:,,,/Images/sunshine.jpg", UriKind.RelativeOrAbsolute));
                    break;
            }

        }
    }
}
